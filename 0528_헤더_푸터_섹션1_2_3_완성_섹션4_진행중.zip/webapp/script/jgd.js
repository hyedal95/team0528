(function ($) {

  class Jgd{

    init() {
      this.nav();
    }
    nav(){
      
      $('.all-menu').on({
        mouseenter(){
          $('.menu-box').stop().slideDown(300);
        },
      });
      
      $('.container').on({
        mouseleave(){
          $('.menu-box').stop().slideUp(300);
        }
      });

      $('.menu').on({
        mouseenter(){
          $('.sub').removeClass('on');
          $(this).next().addClass('on');
        }
      });
    }

  }
  const jgd = new Jgd();
  jgd.init();

})(jQuery);