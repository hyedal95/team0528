(function ($) {

  class Section5{

    init() {
      this.section5();
    }
    section5(){
      let s5cnt = 0;
      let s5SlideCnt = 0;


      function clickSlide(){
        $('.s5-click-wrap').stop().animate({left: `${-400 * s5cnt}px` },500);
      }

      function mainSlide(){
        $('.s5-slide-wrap').stop().animate({left: `${-100 * s5SlideCnt}%` },0);
      }

      //다음 카운트
      function s5nextCount() {
        s5cnt = 1;
        clickSlide();
      }

      //이전 카운트
      function s5prevCount() {
        s5cnt = 0;    
        clickSlide();    
      }


      $('.s5-left-btn-box').on({
        click(){
          s5prevCount();
          $('.s5left-btn').animate({opacity: '0.2'});
          $('.s5right-btn').animate({opacity: '1'});
        }
      });

      $('.s5-right-btn-box').on({
        click(){   
          s5nextCount();
          $('.s5right-btn').animate({opacity: '0.2'});
          $('.s5left-btn').animate({opacity: '1'});
        }
      });


      // 메인슬라이드 이미지 on off
      $('.s5-click-list').each(function(idx){
        $('.s5-click-list').eq(idx).on({
          click() {
            $('.s5-content').removeClass('on');
            $('.s5-top-arrow').removeClass('on');
            $(this).children('.s5-content').addClass('on');
            $(this).children('.s5-top-arrow').addClass('on');

            s5SlideCnt = idx;
            mainSlide();
            
          }
        })

      });




    }
  }
  const section5 = new Section5();
  section5.init();

})(jQuery);