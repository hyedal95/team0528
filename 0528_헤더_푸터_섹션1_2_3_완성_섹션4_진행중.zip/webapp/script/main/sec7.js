(function ($) {

  class Section7{

    init() {
      this.section7();
    }
    section7(){
      let s7cnt = 0;
      let s7SlideCnt = 0;


      function clickSlide(){
        $('.s7-click-wrap').stop().animate({left: `${-370 * s7cnt}px` },600,function(){
          if(s7cnt<0){
            s7cnt=5
          }
          if(s7cnt>5){
            s7cnt=0
          }
          $('.s7-click-wrap').stop().animate({left: `${-370 * s7cnt}px` },0);
          console.log(s7cnt);
        });

        $('.s7-content').removeClass('on');
        $('.s7-click-list').eq(s7cnt+2).children('.s7-content').addClass('on');

      }

      function mainSlide(){
        $('.s7-slide-wrap').stop().animate({left: `${-100 * s7cnt}%` },0);

      }

      //다음 카운트
      function s7nextCount() {
        s7cnt ++;
        clickSlide();
        mainSlide();
      }

      //이전 카운트
      function s7prevCount() {
        s7cnt --; 
        clickSlide();    
        mainSlide();
      }


      $('.s7-left-btn-box').on({
        click(){
          s7prevCount();
        }
      });

      $('.s7-right-btn-box').on({
        click(){   
          s7nextCount();
        }
      });


      // 메인슬라이드 이미지 on off
      $('.s7-click-list').each(function(idx){
        $('.s7-click-list').eq(idx).on({
          click() {
            $('.s7-content').removeClass('on');
            $(this).children('.s7-content').addClass('on');
            console.log(idx)
            
            
            s7cnt = idx-2;
            clickSlide();
            mainSlide();

            // $('.main-img-area').hide();
            // $('.slide-contents').eq(idx).children('div').show();


            // $('.main-img-area').removeClass('on');
            // $('.slide-contents').eq(idx).children('div').addClass('on');
            
            
          }
        })

      });




    }
  }
  const section7 = new Section7();
  section7.init();

})(jQuery);