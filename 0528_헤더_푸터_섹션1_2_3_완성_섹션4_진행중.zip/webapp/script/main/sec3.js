(($)=>{
	class MainSec3 {
		init(){

			this.mainSec3(); 
		}
		mainSec3(){ 
				// 슬라이드는 제이쿼리 이용 
			    // 1. 변수
	            // 2. 메인슬라이드함수
	            // 3. 다음카운트함수
	            // 4. 자동타이머함수
	            // 5. 페이지버튼클릭이벤트
	            // 6. 터치스와이프
	    
	            // 1. 변수
	            let cnt = 0;
	            let setId = 0;
	            let touchStart = null;
	            let touchEnd = null;
	            let mouseDown = false;
	
	            // 2. 메인슬라이드함수 => 0 1 2 
	            function mainSlide(){ 
	                $('.s3-slide-wrap').stop().animate({left:`${-100*cnt}%`},600, function(){
	                    if(cnt>2) cnt= 0;
	                    if(cnt< 0) cnt=2;
	                    $('.s3-slide-wrap').stop().animate({left:`${-100*cnt}%`},0);
	                });
	                
	                // 페이지번호 이벤트
	                $('.s3-page-btn').removeClass('on');
	                $('.s3-page-btn').eq(cnt>2?0:cnt).addClass('on');
	            }
	
	            // 3-1. 다음카운트함수
	            function nextCount(){
	                if( !$('.s3-slide-wrap').is(':animated') ) {
	                    cnt+=1;
	                    mainSlide();
	                }                
	            }
	            // 3-2. 이전카운트함수
	            function prevCount(){
	                if( !$('.s3-slide-wrap').is(':animated') ) {
	                    cnt-=1;
	                    mainSlide();
	                }
	            }
	
	            // 4. 자동타이머함수
	            function autoTimer(){
	                setId = setInterval(nextCount, 3000);
	            }
	            autoTimer();
	
	
	            // 5-1. 페이지버튼클릭이벤트 : idx를 cnt에 저장하고 메인함수 호출 실행
	            $('.s3-page-btn').each(function(idx){         
	                $(this).on({
	                    click(){
	                        clearInterval(setId); //버튼 클릭 시 3초마다 초기화
	                        cnt=idx; // 내가 누른 idx [0,1,2] 가 cnt가 됨. 
	                        mainSlide(); //메인함수 호출해서 해당 cnt값 부터 시작
	                        autoTimer();
	                    }
	                });
	            });
	
	
	            // 6-1. 터치 스와이프 
	            //    - 터치 시작(마우스다운) > 터치 끝(마우스업) => 다음 카운트
	            //    - 터치 시작(마우스다운) < 터치 끝(마우스업) => 이전 카운트
	
	            $('.s3-slide-container').on({
	                mousedown(e){
	                    mouseDown = true;  // 터치시작
	                    $('.s3-slide-container').css({cursor:'grabbing'});
	                    clearInterval(setId);
	                    touchStart = e.clientX;
	                },
	                mouseup(e){   
	                    mouseDown = false;  // 터치끝
	                    $('.s3-slide-container').css({cursor:'grab'});
	                    touchEnd = e.clientX;
	
	                    if(touchStart > touchEnd){
	                        nextCount();
	                    }
	                    if(touchStart < touchEnd){
	                        prevCount();
	                    }
	                    autoTimer();
	                }
	            })
	
	
	            // 6-2. 터치 스와이프
	            //      - mouseDown => true 인경우에만 실행 아니면 종료 return;
	            //      - 즉 마우스다운이 false가 아니면 도큐먼트 마우스업 이벤트 실행
	            //      - 터치 시작은 했는데 마우스업(터치끝)이 슬라이드 영역 밖으로 나가서
	            //        인식이 안되는 경우 즉 마우스업이 없는경우 디버깅
	            $('.s3-slide-container').on({
	                mouseup(e){   
	
	                    // if(mouseDown===false) return;  // mouseDown 이 false 이면
	                    // if(mouseDown!==true) return;      // mouseDown 이 true가 아니면
	                    if(!mouseDown) return;            // mouseDown 이 true가 아니면
	
	                    mouseDown = false;  // 터치끝
	                    $('.s3-slide-container').css({cursor:'grab'});
	                    touchEnd = e.clientX;
	
	                    if(touchStart > touchEnd){
	                        nextCount();
	                    }
	                    if(touchStart < touchEnd){
	                        prevCount();
	                    }
	                    autoTimer();
	                }
	            })
		}
	}
	const mainSec3 = new MainSec3();
	mainSec3.init();	
		
})(jQuery);
