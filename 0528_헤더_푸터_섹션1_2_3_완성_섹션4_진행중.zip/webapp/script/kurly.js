(($)=>{
	class Team {
		init(){
			this.header();
			this.footer();

		}
		header(){
			// 검색창 마우스 호버 효과 
			const searchInput = document.querySelector('#search-input');
			const searchInputResultBox =document.querySelector('.search-input-result-box');
	
			searchInput.addEventListener('click',(e)=>{
				e.preventDefault();
				// 토글이벤트로 클릭할 때마다 클래스 on 활성화 또는 비활성화 
				searchInput.classList.toggle('on');
				searchInputResultBox.classList.toggle('on');
			})
			
			// 로그인 전 & 후
			const before = document.querySelectorAll('.before'); //선택자 2개
			const after = document.querySelectorAll('.after'); //선택자 2개
			const loginBtn = document.querySelector('.login-btn');
			const logoutBtn = document.querySelector('.logout-btn');
			
			// 나중에는 로그인  완료 후 섹션 유지되었을 때 나타나는 것이지만, 
			// 우선 동작 테스트는 로그인 버튼 클릭 시  add
			loginBtn.addEventListener('click',(e)=>{
				e.preventDefault();
				
				before.forEach((item)=>{
					item.classList.add('on');
				})
				after.forEach((item2)=>{
					item2.classList.add('on');
				})
				
	
			})
			// 로그아웃 버튼 클릭시 on클래스 활성화 여부 
			logoutBtn.addEventListener('click',(e)=>{
				e.preventDefault();
				before.forEach((item)=>{
					item.classList.remove('on');
				})
				after.forEach((item2)=>{
					item2.classList.remove('on');
				})
			})
		}
		footer(){
			const up = document.querySelector('.up');
			const down = document.querySelector('.down');
			const familySite = document.querySelector('.family-site');
			const familySiteShow = document.querySelector('.family-site-show');
			
			
			// 패밀리사이트 UP 버튼 클릭 시 => 열림
			up.addEventListener('click', (e)=>{
				e.preventDefault();
				up.classList.add('on');
				down.classList.add('on');
				familySite.classList.add('on');
				familySiteShow.classList.add('on');
			})
			// 패밀리사이트 DOWN 버튼 클릭 시 => 닫힘
			down.addEventListener('click', (e)=>{
				e.preventDefault();
				up.classList.remove('on');
				down.classList.remove('on');
				familySite.classList.remove('on');
				familySiteShow.classList.remove('on');
			})
		}
	}
	const team = new Team();
	team.init();	
		
})(jQuery);

